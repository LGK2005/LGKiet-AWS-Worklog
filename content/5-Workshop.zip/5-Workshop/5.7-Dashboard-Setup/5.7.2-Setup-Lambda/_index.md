---
title : "Create IAM Roles and Policies"
date: "2000-01-01"
weight : 02
chapter : false
pre : " <b> 5.7.2. </b> "
---

In this section, you will create IAM role and Policy for Lambda. After that you will create Lambda Function to execute query

### Content
- [Create Lambda Execution Roles and Policy](5.7.2.1-Create-iam-role-and-policy-for-lambda/)
- [Create Lambda Function](5.7.2.2-Create-lambda-function/)
